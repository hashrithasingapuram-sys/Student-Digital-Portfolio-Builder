// Loads everything a student owns in one go from SQLite.
const { query, queryOne, run, parseRow, parseRows } = require('./db');

function ensureProfile(uid) {
  let profile = parseRow(queryOne('SELECT * FROM profiles WHERE id = ?', [uid]));
  if (!profile) {
    run('INSERT OR IGNORE INTO profiles (id) VALUES (?)', [uid]);
    profile = parseRow(queryOne('SELECT * FROM profiles WHERE id = ?', [uid]));
  }
  return profile;
}

function loadAll(_, uid) {
  const profile = ensureProfile(uid);

  const projects = parseRows(
    query('SELECT * FROM projects WHERE user_id = ? ORDER BY is_featured DESC, completed_on DESC, created_at DESC', [uid])
  );

  const achievements = parseRows(
    query('SELECT * FROM achievements WHERE user_id = ? ORDER BY earned_on DESC, created_at DESC', [uid])
  );

  const resumeRow = parseRow(
    queryOne('SELECT * FROM resume_details WHERE user_id = ?', [uid])
  );

  const checklistRows = query(
    'SELECT task_key, is_done FROM checklist_items WHERE user_id = ?', [uid]
  ).map((r) => ({ task_key: r.task_key, is_done: r.is_done === 1 }));

  return Promise.resolve({
    profile,
    projects,
    achievements,
    resume: resumeRow || {},
    checklistRows,
  });
}

module.exports = { loadAll, ensureProfile };
