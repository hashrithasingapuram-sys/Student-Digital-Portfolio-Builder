// Tiny UUID v4 generator using Node's built-in crypto — no extra dependency.
const { randomUUID } = require('crypto');
module.exports = { v4: randomUUID };
