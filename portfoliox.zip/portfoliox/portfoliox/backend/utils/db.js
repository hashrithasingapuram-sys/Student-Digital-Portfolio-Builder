// SQLite via sql.js (pure JavaScript — no native compilation needed).
// The database is stored as a file (portfoliox.db) next to server.js and
// auto-saved to disk after every write operation.
const path = require('path');
const fs = require('fs');
const initSqlJs = require('sql.js');

const DB_PATH = path.join(__dirname, '..', 'portfoliox.db');

let _db = null; // sql.js Database instance

// Synchronously initialise the database (called once at startup).
async function openDb() {
  const SQL = await initSqlJs();
  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH);
    _db = new SQL.Database(fileBuffer);
  } else {
    _db = new SQL.Database();
  }
  applySchema();
  return _db;
}

// Persist in-memory database to disk.
function save() {
  if (!_db) return;
  const data = _db.export();
  fs.writeFileSync(DB_PATH, Buffer.from(data));
}

function getDb() {
  if (!_db) throw new Error('Database not initialised. Await openDb() before using getDb().');
  return _db;
}

// ── Schema ────────────────────────────────────────────────────────────────────

function applySchema() {
  _db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id            TEXT PRIMARY KEY,
      email         TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
    );

    CREATE TABLE IF NOT EXISTS profiles (
      id                 TEXT PRIMARY KEY REFERENCES users(id),
      username           TEXT UNIQUE,
      full_name          TEXT,
      headline           TEXT,
      intro              TEXT,
      college            TEXT,
      course             TEXT,
      year_of_study      INTEGER,
      technical_skills   TEXT NOT NULL DEFAULT '[]',
      soft_skills        TEXT NOT NULL DEFAULT '[]',
      interests          TEXT NOT NULL DEFAULT '[]',
      github_url         TEXT,
      linkedin_url       TEXT,
      website_url        TEXT,
      contact_email      TEXT,
      is_public          INTEGER NOT NULL DEFAULT 0,
      show_college       INTEGER NOT NULL DEFAULT 1,
      show_contact_email INTEGER NOT NULL DEFAULT 0,
      show_interests     INTEGER NOT NULL DEFAULT 1,
      created_at         TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
      updated_at         TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
    );

    CREATE TABLE IF NOT EXISTS projects (
      id           TEXT PRIMARY KEY,
      user_id      TEXT NOT NULL REFERENCES profiles(id),
      title        TEXT NOT NULL,
      description  TEXT NOT NULL,
      purpose      TEXT,
      technologies TEXT NOT NULL DEFAULT '[]',
      category     TEXT NOT NULL,
      role         TEXT,
      github_url   TEXT,
      live_url     TEXT,
      completed_on TEXT,
      is_featured  INTEGER NOT NULL DEFAULT 0,
      is_public    INTEGER NOT NULL DEFAULT 1,
      created_at   TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
      updated_at   TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
    );
    CREATE INDEX IF NOT EXISTS projects_user_id_idx ON projects(user_id);

    CREATE TABLE IF NOT EXISTS achievements (
      id             TEXT PRIMARY KEY,
      user_id        TEXT NOT NULL REFERENCES profiles(id),
      title          TEXT NOT NULL,
      organization   TEXT NOT NULL,
      category       TEXT NOT NULL,
      earned_on      TEXT NOT NULL,
      credential_url TEXT,
      description    TEXT,
      is_public      INTEGER NOT NULL DEFAULT 1,
      created_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
      updated_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
    );
    CREATE INDEX IF NOT EXISTS achievements_user_id_idx ON achievements(user_id);

    CREATE TABLE IF NOT EXISTS resume_details (
      user_id           TEXT PRIMARY KEY REFERENCES profiles(id),
      objective         TEXT,
      phone             TEXT,
      location          TEXT,
      education_summary TEXT,
      availability      TEXT,
      created_at        TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
      updated_at        TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
    );

    CREATE TABLE IF NOT EXISTS checklist_items (
      id         TEXT PRIMARY KEY,
      user_id    TEXT NOT NULL REFERENCES profiles(id),
      task_key   TEXT NOT NULL,
      is_done    INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
      updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
      UNIQUE(user_id, task_key)
    );
  `);
  save();
}

// ── Query helpers ─────────────────────────────────────────────────────────────

const ARRAY_COLS = new Set(['technical_skills', 'soft_skills', 'interests', 'technologies']);
const BOOL_COLS  = new Set(['is_public', 'show_college', 'show_contact_email', 'show_interests', 'is_featured', 'is_done']);

function parseRow(row) {
  if (!row) return row;
  const out = { ...row };
  for (const col of ARRAY_COLS) {
    if (typeof out[col] === 'string') {
      try { out[col] = JSON.parse(out[col]); } catch { out[col] = []; }
    }
  }
  for (const col of BOOL_COLS) {
    if (col in out && typeof out[col] === 'number') out[col] = out[col] === 1;
  }
  return out;
}

function parseRows(rows) { return rows.map(parseRow); }

function serialiseArrays(obj) {
  const out = { ...obj };
  for (const col of ARRAY_COLS) {
    if (Array.isArray(out[col])) out[col] = JSON.stringify(out[col]);
  }
  return out;
}

// Execute a SELECT and return all matching rows as plain objects.
function query(sql, params = []) {
  const db = getDb();
  const stmt = db.prepare(sql);
  stmt.bind(params);
  const rows = [];
  while (stmt.step()) rows.push(stmt.getAsObject());
  stmt.free();
  return rows;
}

// Return the first matching row, or null.
function queryOne(sql, params = []) {
  const rows = query(sql, params);
  return rows.length > 0 ? rows[0] : null;
}

// Execute a write statement (INSERT / UPDATE / DELETE). Saves to disk.
function run(sql, params = []) {
  const db = getDb();
  db.run(sql, params);
  save();
}

module.exports = { openDb, getDb, save, query, queryOne, run, parseRow, parseRows, serialiseArrays };
