// Verifies the JWT sent by the browser ("Authorization: Bearer <token>").
// On success: req.user = { id, email }
const jwt = require('jsonwebtoken');
const { queryOne } = require('../utils/db');
const { fail } = require('../utils/respond');

const JWT_SECRET = process.env.JWT_SECRET || 'change-me-in-production';

function requireAuth(req, res, next) {
  try {
    const match = (req.headers.authorization || '').match(/^Bearer\s+(\S+)$/i);
    if (!match) return fail(res, 401, 'Please log in to continue.');
    const token = match[1];

    let payload;
    try {
      payload = jwt.verify(token, JWT_SECRET);
    } catch (e) {
      return fail(res, 401, 'Your session has expired. Please log in again.');
    }

    const user = queryOne('SELECT id, email FROM users WHERE id = ?', [payload.sub]);
    if (!user) return fail(res, 401, 'Your session has expired. Please log in again.');

    req.user = user;
    return next();
  } catch (err) {
    return next(err);
  }
}

module.exports = { requireAuth };
