// Auth routes: signup, login.
// POST /api/auth/signup  { email, password, full_name }
// POST /api/auth/login   { email, password }
// POST /api/auth/logout  (stateless — client just discards the token)
const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('../utils/uuid');
const { queryOne, run } = require('../utils/db');
const { asyncHandler } = require('../middleware/errors');
const { ok, fail } = require('../utils/respond');
const { ValidationError } = require('../utils/validate');

const router = express.Router();
const SALT_ROUNDS = 12;
const JWT_SECRET = process.env.JWT_SECRET || 'change-me-in-production';
const JWT_EXPIRES = process.env.JWT_EXPIRES || '7d';

function signToken(userId, email) {
  return jwt.sign({ sub: userId, email }, JWT_SECRET, { expiresIn: JWT_EXPIRES });
}

// POST /api/auth/signup
router.post('/signup', asyncHandler(async (req, res) => {
  const { email, password, full_name } = req.body || {};

  if (!email || typeof email !== 'string' || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim())) {
    throw new ValidationError({ email: 'Enter a valid email address.' });
  }
  if (!password || typeof password !== 'string' || password.length < 8) {
    throw new ValidationError({ password: 'Password must be at least 8 characters.' });
  }
  const cleanEmail = email.trim().toLowerCase();

  const existing = queryOne('SELECT id FROM users WHERE email = ?', [cleanEmail]);
  if (existing) throw new ValidationError({ email: 'An account with that email already exists.' });

  const id = uuidv4();
  const hash = await bcrypt.hash(password, SALT_ROUNDS);
  const now = new Date().toISOString();
  const name = (full_name || '').trim().slice(0, 100) || null;

  run('INSERT INTO users (id, email, password_hash, created_at) VALUES (?, ?, ?, ?)', [id, cleanEmail, hash, now]);
  run('INSERT OR IGNORE INTO profiles (id, full_name, created_at, updated_at) VALUES (?, ?, ?, ?)', [id, name, now, now]);

  const token = signToken(id, cleanEmail);
  return ok(res, { token, user: { id, email: cleanEmail } }, 201);
}));

// POST /api/auth/login
router.post('/login', asyncHandler(async (req, res) => {
  const { email, password } = req.body || {};
  const invalid = () => fail(res, 401, 'Invalid email or password.');
  if (!email || !password) return invalid();

  const cleanEmail = (email + '').trim().toLowerCase();
  const user = queryOne('SELECT * FROM users WHERE email = ?', [cleanEmail]);
  if (!user) return invalid();

  const match = await bcrypt.compare(password + '', user.password_hash);
  if (!match) return invalid();

  const token = signToken(user.id, user.email);
  return ok(res, { token, user: { id: user.id, email: user.email } });
}));

// POST /api/auth/logout
router.post('/logout', (req, res) => ok(res, { message: 'Logged out.' }));

module.exports = router;
