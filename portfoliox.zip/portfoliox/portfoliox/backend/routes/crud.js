// Shared list/create/update/delete routes for tables owned by a student (projects, achievements).
const express = require('express');
const { asyncHandler } = require('../middleware/errors');
const { ok, fail } = require('../utils/respond');
const { isUuid } = require('../utils/validate');
const { query, queryOne, run, parseRow, parseRows, serialiseArrays } = require('../utils/db');
const { v4: uuidv4 } = require('../utils/uuid');

function crudRouter({ table, noun, validate, orderBy }) {
  const router = express.Router();

  const orderClause = orderBy.map(([col, asc]) => `${col} ${asc ? 'ASC' : 'DESC'}`).join(', ');

  // GET /
  router.get('/', asyncHandler(async (req, res) => {
    const rows = parseRows(query(`SELECT * FROM ${table} WHERE user_id = ? ORDER BY ${orderClause}`, [req.user.id]));
    return ok(res, rows);
  }));

  // POST /
  router.post('/', asyncHandler(async (req, res) => {
    const values = validate(req.body);
    const id = uuidv4();
    const now = new Date().toISOString();
    const row = serialiseArrays({ ...values, id, user_id: req.user.id, created_at: now, updated_at: now });

    const cols = Object.keys(row);
    const placeholders = cols.map(() => '?').join(', ');
    run(`INSERT INTO ${table} (${cols.join(', ')}) VALUES (${placeholders})`, Object.values(row));

    const created = parseRow(queryOne(`SELECT * FROM ${table} WHERE id = ?`, [id]));
    return ok(res, created, 201);
  }));

  // PUT /:id
  router.put('/:id', asyncHandler(async (req, res) => {
    if (!isUuid(req.params.id)) return fail(res, 400, `Invalid ${noun} id.`);

    // Check ownership first
    const existing = queryOne(`SELECT id FROM ${table} WHERE id = ? AND user_id = ?`, [req.params.id, req.user.id]);
    if (!existing) return fail(res, 404, `That ${noun} was not found.`);

    const values = validate(req.body);
    const now = new Date().toISOString();
    const row = serialiseArrays({ ...values, updated_at: now });

    const sets = Object.keys(row).map((k) => `${k} = ?`).join(', ');
    run(`UPDATE ${table} SET ${sets} WHERE id = ? AND user_id = ?`, [...Object.values(row), req.params.id, req.user.id]);

    const updated = parseRow(queryOne(`SELECT * FROM ${table} WHERE id = ?`, [req.params.id]));
    return ok(res, updated);
  }));

  // DELETE /:id
  router.delete('/:id', asyncHandler(async (req, res) => {
    if (!isUuid(req.params.id)) return fail(res, 400, `Invalid ${noun} id.`);
    const existing = queryOne(`SELECT id FROM ${table} WHERE id = ? AND user_id = ?`, [req.params.id, req.user.id]);
    if (!existing) return fail(res, 404, `That ${noun} was not found.`);
    run(`DELETE FROM ${table} WHERE id = ? AND user_id = ?`, [req.params.id, req.user.id]);
    return ok(res, { id: req.params.id });
  }));

  return router;
}

module.exports = crudRouter;
