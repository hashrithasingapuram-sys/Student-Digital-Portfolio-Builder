const express = require('express');
const { asyncHandler } = require('../middleware/errors');
const { ok } = require('../utils/respond');
const schemas = require('../utils/schemas');
const { loadAll, ensureProfile } = require('../utils/data');
const { queryOne, run, parseRow } = require('../utils/db');

const router = express.Router();

// GET /api/resume
router.get('/', asyncHandler(async (req, res) => {
  const all = await loadAll(null, req.user.id);
  return ok(res, {
    resume: all.resume,
    profile: all.profile,
    projects: all.projects,
    achievements: all.achievements,
    account_email: req.user.email,
  });
}));

// PUT /api/resume
router.put('/', asyncHandler(async (req, res) => {
  const values = schemas.resume(req.body);
  const now = new Date().toISOString();
  ensureProfile(req.user.id);

  const existing = queryOne('SELECT user_id FROM resume_details WHERE user_id = ?', [req.user.id]);
  if (existing) {
    run(
      'UPDATE resume_details SET objective=?, phone=?, location=?, education_summary=?, availability=?, updated_at=? WHERE user_id=?',
      [values.objective, values.phone, values.location, values.education_summary, values.availability, now, req.user.id]
    );
  } else {
    run(
      'INSERT INTO resume_details (user_id, objective, phone, location, education_summary, availability, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?)',
      [req.user.id, values.objective, values.phone, values.location, values.education_summary, values.availability, now, now]
    );
  }

  const updated = parseRow(queryOne('SELECT * FROM resume_details WHERE user_id = ?', [req.user.id]));
  return ok(res, updated);
}));

module.exports = router;
