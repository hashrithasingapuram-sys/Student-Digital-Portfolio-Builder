// Readiness meter, checklist and dashboard summary. Mounted at /api.
const express = require('express');
const { requireAuth } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errors');
const { ok } = require('../utils/respond');
const schemas = require('../utils/schemas');
const { loadAll, ensureProfile } = require('../utils/data');
const { computeReadiness, profileCompletion, buildChecklist } = require('../utils/readiness');
const { queryOne, run } = require('../utils/db');
const { v4: uuidv4 } = require('../utils/uuid');

function createRouter(authLimiter) {
  const router = express.Router();
  const guard = [authLimiter, requireAuth];

  // GET /api/readiness
  router.get('/readiness', ...guard, asyncHandler(async (req, res) => {
    const all = await loadAll(null, req.user.id);
    const readiness = computeReadiness(all);
    return ok(res, { ...readiness, profile_completion: profileCompletion(all.profile) });
  }));

  // GET /api/checklist
  router.get('/checklist', ...guard, asyncHandler(async (req, res) => {
    const all = await loadAll(null, req.user.id);
    return ok(res, buildChecklist(computeReadiness(all), all.checklistRows));
  }));

  // PUT /api/checklist
  router.put('/checklist', ...guard, asyncHandler(async (req, res) => {
    const { task_key: taskKey, is_done: isDone } = schemas.checklistToggle(req.body);
    ensureProfile(req.user.id);

    const now = new Date().toISOString();
    const existing = queryOne('SELECT id FROM checklist_items WHERE user_id = ? AND task_key = ?', [req.user.id, taskKey]);
    if (existing) {
      run('UPDATE checklist_items SET is_done = ?, updated_at = ? WHERE user_id = ? AND task_key = ?',
        [isDone ? 1 : 0, now, req.user.id, taskKey]);
    } else {
      run('INSERT INTO checklist_items (id, user_id, task_key, is_done, created_at, updated_at) VALUES (?,?,?,?,?,?)',
        [uuidv4(), req.user.id, taskKey, isDone ? 1 : 0, now, now]);
    }

    const all = await loadAll(null, req.user.id);
    return ok(res, buildChecklist(computeReadiness(all), all.checklistRows));
  }));

  // GET /api/dashboard
  router.get('/dashboard', ...guard, asyncHandler(async (req, res) => {
    const all = await loadAll(null, req.user.id);
    const readiness = computeReadiness(all);
    const recent = [...all.projects]
      .sort((a, b) => String(b.created_at).localeCompare(String(a.created_at)))
      .slice(0, 3)
      .map((p) => ({ id: p.id, title: p.title, category: p.category, technologies: p.technologies, completed_on: p.completed_on }));
    return ok(res, {
      name: all.profile.full_name,
      completion: profileCompletion(all.profile),
      counts: { projects: all.projects.length, achievements: all.achievements.length },
      readiness: { score: readiness.score, max: 100, level: readiness.level },
      next_action: readiness.recommendations[0] || null,
      recent_projects: recent,
      checklist: buildChecklist(readiness, all.checklistRows),
    });
  }));

  return router;
}

module.exports = createRouter;
