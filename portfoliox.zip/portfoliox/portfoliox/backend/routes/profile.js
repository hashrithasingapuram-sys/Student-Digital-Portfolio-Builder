const express = require('express');
const { asyncHandler } = require('../middleware/errors');
const { ok } = require('../utils/respond');
const schemas = require('../utils/schemas');
const { loadAll } = require('../utils/data');
const { profileCompletion } = require('../utils/readiness');
const { queryOne, run, parseRow, serialiseArrays } = require('../utils/db');

const router = express.Router();

function present(profile, user) {
  return { ...profile, account_email: user.email, completion: profileCompletion(profile) };
}

// GET /api/profile
router.get('/', asyncHandler(async (req, res) => {
  const { profile } = await loadAll(null, req.user.id);
  return ok(res, present(profile, req.user));
}));

// PUT /api/profile
router.put('/', asyncHandler(async (req, res) => {
  const values = schemas.profile(req.body);
  const now = new Date().toISOString();
  const row = serialiseArrays({ ...values, updated_at: now });

  run('INSERT OR IGNORE INTO profiles (id) VALUES (?)', [req.user.id]);
  const sets = Object.keys(row).map((k) => `${k} = ?`).join(', ');
  run(`UPDATE profiles SET ${sets} WHERE id = ?`, [...Object.values(row), req.user.id]);

  const updated = parseRow(queryOne('SELECT * FROM profiles WHERE id = ?', [req.user.id]));
  return ok(res, present(updated, req.user));
}));

module.exports = router;
