// Public portfolio + sharing settings. Mounted at /api.
const express = require('express');
const { requireAuth } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errors');
const { ok, fail } = require('../utils/respond');
const schemas = require('../utils/schemas');
const { USERNAME_RE, ValidationError } = require('../utils/validate');
const { query, queryOne, run, parseRow, parseRows } = require('../utils/db');

function createRouter(authLimiter) {
  const router = express.Router();
  const guard = [authLimiter, requireAuth];

  // PUT /api/portfolio/settings
  router.put('/portfolio/settings', ...guard, asyncHandler(async (req, res) => {
    const settings = schemas.portfolioSettings(req.body);
    const profile = parseRow(queryOne('SELECT * FROM profiles WHERE id = ?', [req.user.id]));

    if (settings.is_public) {
      if (!settings.username) throw new ValidationError({ username: 'Choose a username before publishing.' });
      if (!profile || !profile.full_name || !profile.headline) {
        throw new ValidationError({ is_public: 'Add your name and headline on the Profile page before publishing.' });
      }
    }

    if (settings.username) {
      const conflict = queryOne('SELECT id FROM profiles WHERE username = ? AND id != ?', [settings.username, req.user.id]);
      if (conflict) throw new ValidationError({ username: 'That username is already taken. Try another.' });
    }

    const now = new Date().toISOString();
    run(
      'UPDATE profiles SET username=?, is_public=?, show_college=?, show_contact_email=?, show_interests=?, updated_at=? WHERE id=?',
      [
        settings.username,
        settings.is_public ? 1 : 0,
        settings.show_college ? 1 : 0,
        settings.show_contact_email ? 1 : 0,
        settings.show_interests ? 1 : 0,
        now,
        req.user.id,
      ]
    );

    const updated = parseRow(queryOne('SELECT * FROM profiles WHERE id = ?', [req.user.id]));
    return ok(res, updated);
  }));

  // GET /api/portfolio-preview
  router.get('/portfolio-preview', ...guard, asyncHandler(async (req, res) => {
    return ok(res, buildPortfolioJson(req.user.id));
  }));

  // GET /api/portfolio/:username  (PUBLIC)
  router.get('/portfolio/:username', asyncHandler(async (req, res) => {
    const username = String(req.params.username || '').toLowerCase();
    const unavailable = 'This portfolio is unavailable. It may be private, or the link may be incorrect.';
    if (!USERNAME_RE.test(username)) return fail(res, 404, unavailable);

    const profile = parseRow(
      queryOne('SELECT * FROM profiles WHERE username = ? AND is_public = 1', [username])
    );
    if (!profile) return fail(res, 404, unavailable);

    return ok(res, buildPortfolioJson(profile.id, profile));
  }));

  return router;
}

function buildPortfolioJson(userId, profileOverride) {
  const profile = profileOverride ||
    parseRow(queryOne('SELECT * FROM profiles WHERE id = ?', [userId])) || {};

  const projects = parseRows(
    query(
      'SELECT * FROM projects WHERE user_id = ? AND is_public = 1 ORDER BY is_featured DESC, completed_on DESC, created_at DESC',
      [userId]
    )
  );

  const achievements = parseRows(
    query(
      'SELECT * FROM achievements WHERE user_id = ? AND is_public = 1 ORDER BY earned_on DESC, created_at DESC',
      [userId]
    )
  );

  return {
    username: profile.username,
    full_name: profile.full_name,
    headline: profile.headline,
    intro: profile.intro,
    college: profile.show_college ? profile.college : null,
    course: profile.show_college ? profile.course : null,
    year_of_study: profile.show_college ? profile.year_of_study : null,
    technical_skills: profile.technical_skills || [],
    soft_skills: profile.soft_skills || [],
    interests: profile.show_interests ? (profile.interests || []) : [],
    github_url: profile.github_url,
    linkedin_url: profile.linkedin_url,
    website_url: profile.website_url,
    contact_email: profile.show_contact_email ? profile.contact_email : null,
    projects: projects.map((p) => ({
      title: p.title, description: p.description, purpose: p.purpose,
      technologies: p.technologies, category: p.category, role: p.role,
      github_url: p.github_url, live_url: p.live_url,
      completed_on: p.completed_on, is_featured: p.is_featured,
    })),
    achievements: achievements.map((a) => ({
      title: a.title, organization: a.organization, category: a.category,
      earned_on: a.earned_on, credential_url: a.credential_url, description: a.description,
    })),
  };
}

module.exports = createRouter;
