// Handles signup and login pages (chosen by <body data-page="...">).
(async function () {
  'use strict';
  const { $, $$ } = PX;
  const page = document.body.dataset.page;
  const msg = $('#form-msg');
  const form = $('#auth-form');
  const show = (type, text) => { msg.className = 'msg msg-' + type; msg.textContent = text; msg.hidden = false; };

  function passwordProblem(pw) {
    if (pw.length < 8) return 'Use at least 8 characters.';
    if (!/[A-Za-z]/.test(pw) || !/[0-9]/.test(pw)) return 'Include at least one letter and one number.';
    return '';
  }

  $$('.toggle-pw').forEach((b) => b.addEventListener('click', () => {
    const input = document.getElementById(b.dataset.target);
    const reveal = input.type === 'password';
    input.type = reveal ? 'text' : 'password';
    b.textContent = reveal ? 'Hide' : 'Show';
    b.setAttribute('aria-pressed', String(reveal));
  }));

  try { await PX.init(); } catch (e) { show('error', e.message); return; }

  const params = new URLSearchParams(location.search);

  if (page === 'login') {
    // Already logged in → go to dashboard.
    if (PX.getToken()) { location.replace(PX.safeNext()); return; }
    if (params.get('reason') === 'expired') show('warn', 'Your session expired. Please log in again.');
    else if (params.get('loggedout')) show('info', 'You have been logged out.');
  }

  if (page === 'signup') {
    form.addEventListener('submit', async (e) => {
      e.preventDefault(); PX.clearErrors(form); msg.hidden = true;
      const v = PX.readForm(form); const errs = {};
      if ((v.full_name || '').trim().length < 2) errs.full_name = 'Enter your full name.';
      if (!v.email.trim()) errs.email = 'Enter your email address.';
      const pwProblem = passwordProblem(v.password); if (pwProblem) errs.password = pwProblem;
      if (v.password !== v.confirm) errs.confirm = 'The two passwords do not match.';
      if (PX.showErrors(form, errs)) return;

      const btn = $('button[type=submit]', form); PX.busy(btn, true, 'Creating account\u2026');
      try {
        const data = await PX.api('/auth/signup', {
          method: 'POST', public: true,
          body: { email: v.email.trim(), password: v.password, full_name: v.full_name.trim() },
        });
        PX.saveSession(data.token, data.user);
        location.href = '/dashboard.html';
      } catch (e) {
        PX.busy(btn, false);
        if (e.fields) PX.showErrors(form, e.fields);
        else show('error', e.message || 'Something went wrong. Please try again.');
      }
    });
  }

  if (page === 'login') {
    form.addEventListener('submit', async (e) => {
      e.preventDefault(); PX.clearErrors(form); msg.hidden = true;
      const v = PX.readForm(form); const errs = {};
      if (!v.email.trim()) errs.email = 'Enter your email address.';
      if (!v.password) errs.password = 'Enter your password.';
      if (PX.showErrors(form, errs)) return;

      const btn = $('button[type=submit]', form); PX.busy(btn, true, 'Logging in\u2026');
      try {
        const data = await PX.api('/auth/login', {
          method: 'POST', public: true,
          body: { email: v.email.trim(), password: v.password },
        });
        PX.saveSession(data.token, data.user);
        location.href = PX.safeNext();
      } catch (e) {
        PX.busy(btn, false);
        show('error', e.message || 'Invalid email or password.');
      }
    });
  }

  // Forgot-password and reset-password are no longer needed with local auth,
  // but we show a friendly message if someone lands on those pages.
  if (page === 'forgot' || page === 'reset') {
    if (form) form.hidden = true;
    show('info', 'Password reset is not available in local mode. Ask your administrator to reset your account directly.');
  }
})();
