(async function () {
  'use strict';
  const { $, h } = PX;
  if (!(await PX.startPrivatePage('resume'))) return;
  const status = $('#status'); const form = $('#resume-form'); const sheet = $('#resume-sheet');
  let data = null;

  const section = (title, ...kids) => h('section', {}, h('h2', {}, title), kids);
  const textLink = (u) => (PX.safeUrl(u) ? u.replace(/^https?:\/\/(www\.)?/i, '') : null);

  // Builds the preview from SAVED profile/projects/achievements plus the (possibly unsaved) form values.
  function renderSheet() {
    if (!data) return;
    const p = data.profile; const r = PX.readForm(form);
    const contact = [p.contact_email || data.account_email, r.phone, r.location, textLink(p.github_url), textLink(p.linkedin_url), textLink(p.website_url)].filter(Boolean);
    const education = [r.education_summary, [p.course, p.college].filter(Boolean).join(', '), p.year_of_study ? PX.yearLabel(p.year_of_study) + ' student' : ''].filter(Boolean);
    const projects = data.projects.slice(0, 5); const achievements = data.achievements.slice(0, 6);
    sheet.replaceChildren(
      h('h1', {}, p.full_name || 'Your Name'),
      p.headline ? h('p', { class: 'rs-head' }, p.headline) : null,
      h('p', { class: 'rs-contact' }, contact.join('  |  ')),
      r.objective ? section('Career objective', h('p', { class: 'rs-sub' }, r.objective)) : null,
      education.length ? section('Education', education.map((line) => h('p', { class: 'rs-sub' }, line))) : null,
      (p.technical_skills.length || p.soft_skills.length) ? section('Skills',
        p.technical_skills.length ? h('p', { class: 'rs-sub' }, h('strong', {}, 'Technical: '), p.technical_skills.join(', ')) : null,
        p.soft_skills.length ? h('p', { class: 'rs-sub' }, h('strong', {}, 'Soft skills: '), p.soft_skills.join(', ')) : null) : null,
      projects.length ? section('Projects', projects.map((x) => h('div', {},
        h('div', { class: 'rs-row' }, h('span', {}, x.title), h('span', {}, x.completed_on ? PX.fmtDate(x.completed_on) : '')),
        h('p', { class: 'rs-sub' }, x.description),
        x.role ? h('p', { class: 'rs-sub' }, 'Role: ' + x.role) : null,
        x.technologies.length ? h('p', { class: 'rs-sub' }, 'Technologies: ' + x.technologies.join(', ')) : null,
        textLink(x.github_url) ? h('p', { class: 'rs-sub' }, 'Code: ' + textLink(x.github_url)) : null))) : null,
      achievements.length ? section('Achievements and certifications', h('ul', {}, achievements.map((a) =>
        h('li', {}, a.title + ' \u2013 ' + a.organization + ' (' + PX.fmtDate(a.earned_on) + ')')))) : null,
      r.availability ? section('Availability', h('p', { class: 'rs-sub' }, r.availability)) : null);
  }

  async function load() {
    PX.setStatus(status, 'info', 'Loading your resume\u2026');
    try {
      data = await PX.api('/resume'); PX.setStatus(status, null);
      PX.fillForm(form, data.resume); renderSheet();
    } catch (e) { PX.setStatus(status, 'error', e.message, load); }
  }

  form.addEventListener('input', renderSheet);
  form.addEventListener('submit', async (e) => {
    e.preventDefault(); PX.clearErrors(form);
    const btn = $('button[type=submit]', form); PX.busy(btn, true, 'Saving\u2026');
    try { data.resume = await PX.api('/resume', { method: 'PUT', body: PX.readForm(form) }); renderSheet(); PX.refreshScore(true); }
    catch (err) { if (err.fields) PX.showErrors(form, err.fields); PX.toast(err.message, 'error'); }
    finally { PX.busy(btn, false); }
  });
  $('#print-btn').addEventListener('click', () => { PX.toast('In the print window, choose "Save as PDF" as the destination.', 'info'); setTimeout(() => window.print(), 400); });
  load();
})();
